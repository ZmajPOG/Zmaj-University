<?php
session_start();
require __DIR__ . '/config/db.php';

// If already logged in, redirect to the correct dashboard
if (isset($_SESSION['user_id'], $_SESSION['uloga'])) {
    if ($_SESSION['uloga'] === 'admin') {
        header('Location: admin/dashboard.php');
        exit;
    } elseif ($_SESSION['uloga'] === 'profesor') {
        header('Location: professor/dashboard.php');
        exit;
    } elseif ($_SESSION['uloga'] === 'student') {
        header('Location: student/dashboard.php');
        exit;
    }
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $sql = "SELECT user_id, ime, prezime, uloga 
                FROM users 
                WHERE email = ? AND lozinka = SHA2(?, 256)
                LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email, $password]);
        $user = $stmt->fetch();

        if ($user) {
            $_SESSION['user_id']  = $user['user_id'];
            $_SESSION['ime']      = $user['ime'];
            $_SESSION['prezime']  = $user['prezime'];
            $_SESSION['uloga']    = $user['uloga'];

            if ($user['uloga'] === 'admin') {
                header('Location: admin/dashboard.php');
            } elseif ($user['uloga'] === 'profesor') {
                header('Location: professor/dashboard.php');
            } else {
                header('Location: student/dashboard.php');
            }
            exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Zmaj University - Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="assets/css/custom.css?v=3" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>


<body class="bg-light d-flex align-items-center login-page" style="min-height: 100vh;">
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-sm login-card">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-center mb-3">
                        <span class="logo-pill login-logo-pulse">Z</span>
                    </div>
                    <h3 class="mb-1 text-center">Zmaj University</h3>
                    <p class="text-center text-muted mb-4">Faculty Information System</p>

                    <?php if ($error): ?>
                        <div class="alert alert-danger">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <form method="post" novalidate>
                        <div class="mb-3">
                            <label for="email" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="email" name="email"
                                   placeholder="admin@zmaj.univ" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password"
                                   placeholder="Enter your password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            Sign in
                        </button>
                    </form>

                    <!-- Test accounts with click-to-copy -->
                    <div class="mt-3 small text-muted login-tip">
                        <strong>Test accounts</strong> – click the email or password to copy:
                    </div>

                    <div class="login-test-accounts small">
                        <div class="login-test-row">
                            <span class="login-role-badge">Admin</span>
                            <button type="button" class="login-copy-pill" data-copy="admin@zmaj.univ">
                                admin@zmaj.univ
                            </button>
                            <span class="text-muted mx-1">/</span>
                            <button type="button" class="login-copy-pill" data-copy="admin123">
                                admin123
                            </button>
                        </div>

                        <div class="login-test-row">
                            <span class="login-role-badge">Professor</span>
                            <button type="button" class="login-copy-pill" data-copy="milan.petrovic@zmaj.univ">
                                milan.petrovic@zmaj.univ
                            </button>
                            <span class="text-muted mx-1">/</span>
                            <button type="button" class="login-copy-pill" data-copy="prof123">
                                prof123
                            </button>
                        </div>

                        <div class="login-test-row">
                            <span class="login-role-badge">Student</span>
                            <button type="button" class="login-copy-pill" data-copy="s001@zmaj.univ">
                                s001@zmaj.univ
                            </button>
                            <span class="text-muted mx-1">/</span>
                            <button type="button" class="login-copy-pill" data-copy="stud123">
                                stud123
                            </button>
                        </div>
                    </div>

                    <div id="copy-tip" class="login-copy-tip small text-success mt-2">
                        Click any credential above to copy it to clipboard.
                    </div>

                    <!-- Docs link -->
                    <a href="https://f.jovanhq.tech/docs" target="_blank" class="login-docs-link mt-3">
                        <span class="login-docs-icon">
                            <i class="bi bi-journal-text"></i>
                        </span>
                        <span>
                            <strong>Open project documentation</strong><br>
                            <span class="login-docs-sub">
                                Seminar paper &amp; system documentation · opens in a new tab
                            </span>
                        </span>
                    </a>
                </div>
            </div>
            <p class="text-center text-muted mt-3 mb-0">&copy; <?php echo date('Y'); ?> jovanhq.tech</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const tip = document.getElementById('copy-tip');
    const defaultTip = tip ? tip.textContent : '';
    const buttons = document.querySelectorAll('[data-copy]');

    buttons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            const text = btn.getAttribute('data-copy') || '';
            if (!text) return;

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () {
                    if (!tip) return;
                    tip.textContent = 'Copied: ' + text;
                    tip.classList.add('show');
                    clearTimeout(window._loginCopyTimer);
                    window._loginCopyTimer = setTimeout(function () {
                        tip.textContent = defaultTip;
                        tip.classList.remove('show');
                    }, 1600);
                }).catch(function (err) {
                    console.error(err);
                    if (tip) {
                        tip.textContent = 'Could not copy automatically. Please copy manually.';
                        tip.classList.add('show');
                    }
                });
            } else {
                if (tip) {
                    tip.textContent = 'Clipboard not available. Please copy manually.';
                    tip.classList.add('show');
                }
            }
        });
    });
});
</script>
</body>
</html>
