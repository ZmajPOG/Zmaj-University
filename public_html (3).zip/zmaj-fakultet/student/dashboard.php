<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$studentId = (int)$_SESSION['user_id'];

function h($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

// Enrolled courses
$stmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE student_id = ?");
$stmt->execute([$studentId]);
$enrolledCount = (int)$stmt->fetchColumn();

// Active exam periods
$stmt = $pdo->query("SELECT COUNT(*) FROM exam_periods WHERE aktivan = 1");
$activePeriods = (int)$stmt->fetchColumn();

// Exam applications in active periods
$sql = "
    SELECT COUNT(*)
    FROM exam_applications ea
    JOIN exam_periods p ON p.period_id = ea.period_id
    WHERE ea.student_id = :sid AND p.aktivan = 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute(['sid' => $studentId]);
$appsInActive = (int)$stmt->fetchColumn();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Student - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>



<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-success mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-light fw-normal d-none d-sm-inline">Student</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarStudent">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarStudent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php') echo 'active'; ?>" href="courses.php">
            <i class="bi bi-journal-bookmark"></i> Courses & enrollments
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'my_courses.php' || $current === 'course_details.php') echo 'active'; ?>"
             href="my_courses.php">
            <i class="bi bi-book"></i> My courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exams.php') echo 'active'; ?>" href="exams.php">
            <i class="bi bi-clipboard-check"></i> Exams
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'grades.php') echo 'active'; ?>" href="grades.php">
            <i class="bi bi-bar-chart-line"></i> Grades
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'announcements.php') echo 'active'; ?>" href="announcements.php">
            <i class="bi bi-bell"></i> Announcements
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'profile.php') echo 'active'; ?>" href="profile.php">
            <i class="bi bi-person-badge"></i> My profile
          </a>
        </li>

      </ul>

        <div class="d-flex align-items-center">
        <a href="profile.php" class="navbar-text me-3 small navbar-profile-link">
          <i class="bi bi-person-badge-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </a>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>

    </div>
  </div>
</nav>



<div class="container">
    <h1 class="h3 mb-4">Student Dashboard</h1>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Enrolled courses</h5>
                    <p class="display-6 mb-0"><?php echo $enrolledCount; ?></p>
                    <p class="text-muted mb-0">Courses you are currently enrolled in.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Active exam periods</h5>
                    <p class="display-6 mb-0"><?php echo $activePeriods; ?></p>
                    <p class="text-muted mb-0">Set by administration.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Exam applications</h5>
                    <p class="display-6 mb-0"><?php echo $appsInActive; ?></p>
                    <p class="text-muted mb-0">Applications you have in active periods.</p>
                </div>
            </div>
        </div>
    </div>

        <h2 class="h5 mt-4 mb-3">Quick actions</h2>
    <div class="quick-actions-grid">

        <a href="courses.php" class="quick-card quick-card-student">
            <div class="quick-card-icon">
                <i class="bi bi-journal-bookmark"></i>
            </div>
            <div>
                <div class="quick-card-title">Courses</div>
                <div class="quick-card-main">Browse & enroll</div>
                <div class="quick-card-text">
                    View all available courses and manage your enrollments.
                </div>
            </div>
        </a>

        <a href="my_courses.php" class="quick-card quick-card-student">
            <div class="quick-card-icon">
                <i class="bi bi-book-half"></i>
            </div>
            <div>
                <div class="quick-card-title">My courses</div>
                <div class="quick-card-main">Follow subjects</div>
                <div class="quick-card-text">
                    Open the list of courses you are currently enrolled in.
                </div>
            </div>
        </a>

        <a href="exams.php" class="quick-card quick-card-student">
            <div class="quick-card-icon">
                <i class="bi bi-clipboard-check"></i>
            </div>
            <div>
                <div class="quick-card-title">Exams</div>
                <div class="quick-card-main">Apply for exams</div>
                <div class="quick-card-text">
                    Register for exam terms in active exam periods.
                </div>
            </div>
        </a>

        <a href="grades.php" class="quick-card quick-card-student">
            <div class="quick-card-icon">
                <i class="bi bi-bar-chart-line"></i>
            </div>
            <div>
                <div class="quick-card-title">Grades</div>
                <div class="quick-card-main">Check results</div>
                <div class="quick-card-text">
                    Overview of your grades and passed exams.
                </div>
            </div>
        </a>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
