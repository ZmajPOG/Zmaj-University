<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$studentId = (int)$_SESSION['user_id'];
$courseId  = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;

if ($courseId > 0) {
    // later we could forbid unenroll if there is already a grade/exam application
    $stmt = $pdo->prepare("DELETE FROM enrollments WHERE student_id = ? AND course_id = ?");
    $stmt->execute([$studentId, $courseId]);
}

header('Location: courses.php');
exit;
