<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$studentId = (int)$_SESSION['user_id'];

// --------------------
// Handle POST (apply / cancel)
// --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action   = $_POST['action'] ?? '';
    $courseId = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    $periodId = isset($_POST['period_id']) ? (int)$_POST['period_id'] : 0;

    if ($courseId > 0 && $periodId > 0) {
        // make sure period is active
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM exam_periods WHERE period_id = ? AND aktivan = 1");
        $stmt->execute([$periodId]);
        $isActivePeriod = (int)$stmt->fetchColumn() > 0;

        if ($isActivePeriod) {
            if ($action === 'apply') {
                // check if already exists
                $stmt = $pdo->prepare("
                    SELECT application_id
                    FROM exam_applications
                    WHERE student_id = ? AND course_id = ? AND period_id = ?
                ");
                $stmt->execute([$studentId, $courseId, $periodId]);
                $existing = $stmt->fetch();

                if (!$existing) {
                    $stmt = $pdo->prepare("
                        INSERT INTO exam_applications (student_id, course_id, period_id, status)
                        VALUES (?, ?, ?, 'prijavljen')
                    ");
                    $stmt->execute([$studentId, $courseId, $periodId]);
                }
            } elseif ($action === 'cancel') {
                // allow cancel only while status is "prijavljen" or NULL
                $stmt = $pdo->prepare("
                    DELETE FROM exam_applications
                    WHERE student_id = ? AND course_id = ? AND period_id = ?
                      AND (status = 'prijavljen' OR status IS NULL)
                ");
                $stmt->execute([$studentId, $courseId, $periodId]);
            }
        }
    }

    // avoid resubmitting on refresh
    header('Location: exams.php?period_id=' . $periodId);
    exit;
}

// --------------------
// Load active exam periods
// --------------------
$stmt = $pdo->query("
    SELECT period_id, naziv, datum_od, datum_do
    FROM exam_periods
    WHERE aktivan = 1
    ORDER BY datum_od
");
$periods = $stmt->fetchAll();

$currentPeriodId = 0;
if ($periods) {
    $currentPeriodId = isset($_GET['period_id']) ? (int)$_GET['period_id'] : (int)$periods[0]['period_id'];
    // if selected period is not active any more, fall back to first
    $validIds = array_column($periods, 'period_id');
    if (!in_array($currentPeriodId, $validIds, true)) {
        $currentPeriodId = (int)$periods[0]['period_id'];
    }
}

// --------------------
// Load student's enrolled courses + application status in selected period
// --------------------
$courses = [];
$search = trim($_GET['q'] ?? '');

if ($currentPeriodId > 0) {
    $sql = "
        SELECT
            c.course_id,
            c.sifra,
            c.naziv,
            c.espb,
            p.ime  AS profesor_ime,
            p.prezime AS profesor_prezime,
            ea.application_id,
            ea.status
        FROM enrollments e
        JOIN courses c  ON e.course_id = c.course_id
        LEFT JOIN users p ON c.profesor_id = p.user_id
        LEFT JOIN exam_applications ea
               ON ea.course_id = c.course_id
              AND ea.student_id = e.student_id
              AND ea.period_id = :period_id
        WHERE e.student_id = :student_id
    ";

        $params = [
        'period_id'  => $currentPeriodId,
        'student_id' => $studentId,
    ];

    if ($search !== '') {
        $sql .= " AND (c.naziv LIKE :s1 OR c.sifra LIKE :s2)";
        $like = '%' . $search . '%';
        $params['s1'] = $like;
        $params['s2'] = $like;
    }


    $sql .= " ORDER BY c.sifra";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $courses = $stmt->fetchAll();
}

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Student - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-success mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-light fw-normal d-none d-sm-inline">Student</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarStudent">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarStudent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php') echo 'active'; ?>" href="courses.php">
            <i class="bi bi-journal-bookmark"></i> Courses & enrollments
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'my_courses.php' || $current === 'course_details.php') echo 'active'; ?>"
             href="my_courses.php">
            <i class="bi bi-book"></i> My courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exams.php') echo 'active'; ?>" href="exams.php">
            <i class="bi bi-clipboard-check"></i> Exams
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'grades.php') echo 'active'; ?>" href="grades.php">
            <i class="bi bi-bar-chart-line"></i> Grades
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'announcements.php') echo 'active'; ?>" href="announcements.php">
            <i class="bi bi-bell"></i> Announcements
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'profile.php') echo 'active'; ?>" href="profile.php">
            <i class="bi bi-person-badge"></i> My profile
          </a>
        </li>

      </ul>

        <div class="d-flex align-items-center">
        <a href="profile.php" class="navbar-text me-3 small navbar-profile-link">
          <i class="bi bi-person-badge-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </a>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>

    </div>
  </div>
</nav>




<div class="container">
    <h1 class="h3 mb-4">Exam registration</h1>

    <?php if (!$periods): ?>
        <div class="alert alert-info">
            There are currently no active exam periods. Please check again later.
        </div>
    <?php else: ?>

        <!-- Choose active period -->
        <form class="row g-3 align-items-center mb-3" method="get">
            <div class="col-md-4">
                <label class="form-label">Exam period</label>
                <select name="period_id" class="form-select" onchange="this.form.submit()">
                    <?php foreach ($periods as $p): ?>
                        <option value="<?php echo (int)$p['period_id']; ?>"
                            <?php if ($currentPeriodId == (int)$p['period_id']) echo 'selected'; ?>>
                            <?php
                                echo h($p['naziv']) . ' (' . h($p['datum_od']) . ' – ' . h($p['datum_do']) . ')';
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Search course</label>
                <input type="text" name="q" class="form-control"
                       value="<?php echo h($search); ?>" placeholder="By name or code">
            </div>
            <div class="col-md-2">
                <label class="form-label d-none d-md-block">&nbsp;</label>
                <button type="submit" class="btn btn-outline-secondary w-100">Filter</button>
            </div>
        </form>

        <?php if (!$courses): ?>
            <div class="alert alert-warning">
                You have no enrolled courses or nothing matches the filter.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>Code</th>
                        <th>Course</th>
                        <th>ESPB</th>
                        <th>Professor</th>
                        <th>Status</th>
                        <th style="width: 180px;">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($courses as $c): ?>
                        <?php
                        $applied = !empty($c['application_id']);
                        $status  = $c['status'] ?? null;
                        ?>
                        <tr>
                            <td><?php echo h($c['sifra']); ?></td>
                            <td><?php echo h($c['naziv']); ?></td>
                            <td><?php echo (int)$c['espb']; ?></td>
                            <td><?php echo h($c['profesor_ime'] . ' ' . $c['profesor_prezime']); ?></td>
                            <td>
                                <?php if (!$applied): ?>
                                    <span class="badge bg-secondary">Not applied</span>
                                <?php else: ?>
                                    <?php if ($status === 'polozio' || $status === 'položio'): ?>
                                        <span class="badge bg-success">Passed</span>
                                    <?php elseif ($status === 'pao' || $status === 'nije položio'): ?>
                                        <span class="badge bg-danger">Failed</span>
                                    <?php else: ?>
                                        <span class="badge bg-primary">Registered</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$applied): ?>
                                    <form method="post" class="d-inline">
                                        <input type="hidden" name="course_id" value="<?php echo (int)$c['course_id']; ?>">
                                        <input type="hidden" name="period_id" value="<?php echo (int)$currentPeriodId; ?>">
                                        <input type="hidden" name="action" value="apply">
                                        <button type="submit" class="btn btn-sm btn-success">
                                            Apply for exam
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <?php if ($status === 'prijavljen' || $status === null || $status === ''): ?>
                                        <form method="post" class="d-inline" onsubmit="return confirm('Cancel this application?');">
                                            <input type="hidden" name="course_id" value="<?php echo (int)$c['course_id']; ?>">
                                            <input type="hidden" name="period_id" value="<?php echo (int)$currentPeriodId; ?>">
                                            <input type="hidden" name="action" value="cancel">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                Cancel application
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small">
                                            (Cannot change after grading)
                                        </span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
