<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'student') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$studentId = (int)$_SESSION['user_id'];
$courseId  = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;

if ($courseId > 0) {
    // check if course exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE course_id = ?");
    $stmt->execute([$courseId]);
    if ($stmt->fetchColumn() > 0) {
        // prevent duplicates
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM enrollments WHERE student_id = ? AND course_id = ?");
        $stmt->execute([$studentId, $courseId]);
        if ($stmt->fetchColumn() == 0) {
            $stmt = $pdo->prepare("
                INSERT INTO enrollments (student_id, course_id)
                VALUES (?, ?)
            ");
            $stmt->execute([$studentId, $courseId]);
        }
    }
}

header('Location: courses.php');
exit;
