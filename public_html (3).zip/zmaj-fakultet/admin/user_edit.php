<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: users.php');
    exit;
}

// Fetch user
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: users.php?notfound=1');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ime      = trim($_POST['ime'] ?? '');
    $prezime  = trim($_POST['prezime'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $uloga    = $_POST['uloga'] ?? '';
    $indeks   = trim($_POST['indeks'] ?? '');
    $smer     = trim($_POST['smer'] ?? '');
    $godina   = $_POST['godina'] !== '' ? (int)$_POST['godina'] : null;

    if ($ime === '' || $prezime === '' || $email === '' || $uloga === '') {
        $errors[] = 'Name, email and role are required.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format.';
    }

    if (!in_array($uloga, ['admin','profesor','student'], true)) {
        $errors[] = 'Invalid role selected.';
    }

    // Unique email except this user
    if (!$errors) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?");
        $stmt->execute([$email, $id]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = 'Another user with that email already exists.';
        }
    }

    if (!$errors) {
        if ($password !== '') {
            $hashedPassword = hash('sha256', $password);
            $sql = "UPDATE users
                    SET ime = :ime, prezime = :prezime, email = :email,
                        lozinka = :lozinka, uloga = :uloga,
                        indeks = :indeks, smer = :smer, godina = :godina
                    WHERE user_id = :id";
        } else {
            $sql = "UPDATE users
                    SET ime = :ime, prezime = :prezime, email = :email,
                        uloga = :uloga,
                        indeks = :indeks, smer = :smer, godina = :godina
                    WHERE user_id = :id";
        }

        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':ime', $ime);
        $stmt->bindValue(':prezime', $prezime);
        $stmt->bindValue(':email', $email);
        $stmt->bindValue(':uloga', $uloga);
        $stmt->bindValue(':indeks', $indeks !== '' ? $indeks : null, $indeks !== '' ? PDO::PARAM_STR : PDO::PARAM_NULL);
        $stmt->bindValue(':smer', $smer !== '' ? $smer : null, $smer !== '' ? PDO::PARAM_STR : PDO::PARAM_NULL);
        if ($godina !== null) {
            $stmt->bindValue(':godina', $godina, PDO::PARAM_INT);
        } else {
            $stmt->bindValue(':godina', null, PDO::PARAM_NULL);
        }
        if ($password !== '') {
            $stmt->bindValue(':lozinka', $hashedPassword);
        }
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        header('Location: users.php?updated=1');
        exit;
    }
} else {
    // pre-fill from DB
    $ime = $user['ime'];
    $prezime = $user['prezime'];
    $email = $user['email'];
    $uloga = $user['uloga'];
    $indeks = $user['indeks'];
    $smer = $user['smer'];
    $godina = $user['godina'];
}

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Zmaj University - Admin</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="users.php">Users</a></li>
      </ul>
      <div class="d-flex">
        <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
  <h1 class="h3 mb-4">Edit user #<?php echo (int)$id; ?></h1>

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $e): ?>
          <li><?php echo h($e); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">First name</label>
      <input type="text" name="ime" class="form-control" value="<?php echo h($ime); ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Last name</label>
      <input type="text" name="prezime" class="form-control" value="<?php echo h($prezime); ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">E-mail</label>
      <input type="email" name="email" class="form-control" value="<?php echo h($email); ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">New password (leave blank to keep current)</label>
      <input type="password" name="password" class="form-control">
    </div>
    <div class="col-md-4">
      <label class="form-label">Role</label>
      <select name="uloga" class="form-select" required>
        <option value="admin" <?php echo ($uloga==='admin')?'selected':''; ?>>Admin</option>
        <option value="profesor" <?php echo ($uloga==='profesor')?'selected':''; ?>>Professor</option>
        <option value="student" <?php echo ($uloga==='student')?'selected':''; ?>>Student</option>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Index (for students)</label>
      <input type="text" name="indeks" class="form-control" value="<?php echo h($indeks); ?>">
    </div>
    <div class="col-md-4">
      <label class="form-label">Year of study</label>
      <input type="number" min="1" max="5" name="godina" class="form-control"
             value="<?php echo h($godina); ?>">
    </div>
    <div class="col-md-12">
      <label class="form-label">Study program</label>
      <input type="text" name="smer" class="form-control" value="<?php echo h($smer); ?>">
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Save changes</button>
      <a href="users.php" class="btn btn-secondary">Back</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
