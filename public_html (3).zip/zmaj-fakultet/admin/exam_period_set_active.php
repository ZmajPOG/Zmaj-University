<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$mode = $_GET['mode'] ?? 'on';

if ($id > 0) {
    // Check if period exists
    $stmt = $pdo->prepare("SELECT aktivan FROM exam_periods WHERE period_id = ?");
    $stmt->execute([$id]);
    $period = $stmt->fetch();

    if ($period) {
        if ($mode === 'off') {
            // Just deactivate this one
            $stmt = $pdo->prepare("UPDATE exam_periods SET aktivan = 0 WHERE period_id = ?");
            $stmt->execute([$id]);
        } else {
            // Activate this one and deactivate all others
            $pdo->exec("UPDATE exam_periods SET aktivan = 0");
            $stmt = $pdo->prepare("UPDATE exam_periods SET aktivan = 1 WHERE period_id = ?");
            $stmt->execute([$id]);
        }
    }
}

header('Location: exam_periods.php');
exit;
