<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$today = date('Y-m-d');

// --------------
// Basic counters
// --------------
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();

$roles = $pdo->query("
    SELECT uloga, COUNT(*) AS cnt
    FROM users
    GROUP BY uloga
")->fetchAll();

$totalCourses = (int)$pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();

$totalExamPeriods = (int)$pdo->query("SELECT COUNT(*) FROM exam_periods")->fetchColumn();

$activePeriods = (int)$pdo->query("
    SELECT COUNT(*)
    FROM exam_periods
    WHERE aktivan = 1
")->fetchColumn();

// exam applications
$appsByStatus = $pdo->query("
    SELECT COALESCE(status, 'bez_statusa') AS status, COUNT(*) AS cnt
    FROM exam_applications
    GROUP BY COALESCE(status, 'bez_statusa')
")->fetchAll();

$totalExamApps = 0;
foreach ($appsByStatus as $row) {
    $totalExamApps += (int)$row['cnt'];
}

// grades count
$totalGrades = (int)$pdo->query("SELECT COUNT(*) FROM grades")->fetchColumn();

// ---------------------------
// Top 5 courses by enrollment
// ---------------------------
$popularCourses = $pdo->query("
    SELECT
        c.course_id,
        c.sifra,
        c.naziv,
        COUNT(e.student_id) AS enrolled_count
    FROM courses c
    LEFT JOIN enrollments e ON e.course_id = c.course_id
    GROUP BY c.course_id, c.sifra, c.naziv
    ORDER BY enrolled_count DESC, c.naziv
    LIMIT 5
")->fetchAll();

// ---------------------------
// Grades distribution
// ---------------------------
$gradesDistribution = $pdo->query("
    SELECT ocena, COUNT(*) AS cnt
    FROM grades
    GROUP BY ocena
    ORDER BY ocena
")->fetchAll();

// ---------------------------
// Exam applications per period
// ---------------------------
$appsPerPeriod = $pdo->query("
    SELECT
        ep.naziv,
        ep.datum_od,
        ep.datum_do,
        COUNT(ea.application_id) AS app_count
    FROM exam_periods ep
    LEFT JOIN exam_applications ea ON ea.period_id = ep.period_id
    GROUP BY ep.period_id, ep.naziv, ep.datum_od, ep.datum_do
    ORDER BY ep.datum_od
")->fetchAll();

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>

<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-secondary fw-normal d-none d-sm-inline">Admin panel</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'users.php') echo 'active'; ?>" href="users.php">
            <i class="bi bi-people"></i> Users
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php') echo 'active'; ?>" href="courses.php">
            <i class="bi bi-journal-code"></i> Courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exam_periods.php') echo 'active'; ?>" href="exam_periods.php">
            <i class="bi bi-calendar-event"></i> Exam periods
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'announcements.php') echo 'active'; ?>" href="announcements.php">
            <i class="bi bi-megaphone"></i> Announcements
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'statistics.php') echo 'active'; ?>" href="statistics.php">
            <i class="bi bi-graph-up"></i> Statistics
          </a>
        </li>

      </ul>

      <div class="d-flex align-items-center">
        <span class="navbar-text me-3 small">
          <i class="bi bi-shield-lock-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>


<div class="container">
  <h1 class="h3 mb-3">System statistics</h1>
  <p class="text-muted">
    Today is <strong><?php echo h($today); ?></strong>.
  </p>

  <!-- Summary cards -->
  <div class="row g-3 mb-4">
    <div class="col-md-3">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Users</h5>
          <p class="display-6 mb-0"><?php echo $totalUsers; ?></p>
          <small class="text-muted">
            <?php
              $roleLabels = [];
              foreach ($roles as $r) {
                  $roleLabels[] = h($r['uloga']) . ': ' . (int)$r['cnt'];
              }
              echo implode(' | ', $roleLabels);
            ?>
          </small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Courses</h5>
          <p class="display-6 mb-0"><?php echo $totalCourses; ?></p>
          <small class="text-muted">Total active in system</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Exam periods</h5>
          <p class="display-6 mb-0"><?php echo $totalExamPeriods; ?></p>
          <small class="text-muted">
            Active now: <?php echo $activePeriods; ?>
          </small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-0 shadow-sm">
        <div class="card-body">
          <h5 class="card-title">Exam applications</h5>
          <p class="display-6 mb-0"><?php echo $totalExamApps; ?></p>
          <small class="text-muted">
            Total applications; grades: <?php echo $totalGrades; ?>
          </small>
        </div>
      </div>
    </div>
  </div>

  <!-- Exam applications by status -->
  <div class="row mb-4">
    <div class="col-md-6">
      <h2 class="h5">Exam applications by status</h2>
      <?php if (!$appsByStatus): ?>
        <div class="alert alert-info mt-2">No exam applications yet.</div>
      <?php else: ?>
        <table class="table table-sm table-striped mt-2">
          <thead class="table-light">
            <tr>
              <th>Status</th>
              <th class="text-end">Count</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($appsByStatus as $row): ?>
            <tr>
              <td>
                <?php
                  $st = $row['status'];
                  if ($st === 'bez_statusa' || $st === null || $st === '') $st = 'n/a';
                  echo h($st);
                ?>
              </td>
              <td class="text-end"><?php echo (int)$row['cnt']; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <h2 class="h5">Grades distribution</h2>
      <?php if (!$gradesDistribution): ?>
        <div class="alert alert-info mt-2">No grades entered yet.</div>
      <?php else: ?>
        <table class="table table-sm table-striped mt-2">
          <thead class="table-light">
            <tr>
              <th>Grade</th>
              <th class="text-end">Count</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($gradesDistribution as $g): ?>
            <tr>
              <td><?php echo (int)$g['ocena']; ?></td>
              <td class="text-end"><?php echo (int)$g['cnt']; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>

  <!-- Top courses + apps per period -->
  <div class="row mb-4">
    <div class="col-md-6">
      <h2 class="h5">Top 5 courses by enrollment</h2>
      <?php if (!$popularCourses): ?>
        <div class="alert alert-info mt-2">No enrollments yet.</div>
      <?php else: ?>
        <table class="table table-sm table-striped mt-2">
          <thead class="table-light">
            <tr>
              <th>Code</th>
              <th>Course</th>
              <th class="text-end">Students</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($popularCourses as $c): ?>
            <tr>
              <td><?php echo h($c['sifra']); ?></td>
              <td><?php echo h($c['naziv']); ?></td>
              <td class="text-end"><?php echo (int)$c['enrolled_count']; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <div class="col-md-6">
      <h2 class="h5">Applications per exam period</h2>
      <?php if (!$appsPerPeriod): ?>
        <div class="alert alert-info mt-2">No exam periods or applications yet.</div>
      <?php else: ?>
        <table class="table table-sm table-striped mt-2">
          <thead class="table-light">
            <tr>
              <th>Period</th>
              <th>Dates</th>
              <th class="text-end">Applications</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($appsPerPeriod as $p): ?>
            <tr>
              <td><?php echo h($p['naziv']); ?></td>
              <td>
                <?php echo h($p['datum_od']); ?> – <?php echo h($p['datum_do']); ?>
              </td>
              <td class="text-end"><?php echo (int)$p['app_count']; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
