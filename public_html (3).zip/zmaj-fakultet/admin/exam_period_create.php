<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naziv    = trim($_POST['naziv'] ?? '');
    $datum_od = trim($_POST['datum_od'] ?? '');
    $datum_do = trim($_POST['datum_do'] ?? '');

    if ($naziv === '' || $datum_od === '' || $datum_do === '') {
        $errors[] = 'Name and both dates are required.';
    }

    // Very simple date validation (YYYY-MM-DD)
    foreach (['datum_od' => $datum_od, 'datum_do' => $datum_do] as $label => $val) {
        if ($val !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $val)) {
            $errors[] = "Invalid date format for $label (expected YYYY-MM-DD).";
        }
    }

    if (!$errors) {
        $sql = "INSERT INTO exam_periods (naziv, datum_od, datum_do, aktivan)
                VALUES (:naziv, :datum_od, :datum_do, 0)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':naziv'    => $naziv,
            ':datum_od' => $datum_od,
            ':datum_do' => $datum_do,
        ]);

        header('Location: exam_periods.php?created=1');
        exit;
    }
}

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Zmaj University - Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">Users</a></li>
        <li class="nav-item"><a class="nav-link" href="courses.php">Courses</a></li>
        <li class="nav-item"><a class="nav-link active" href="exam_periods.php">Exam periods</a></li>
      </ul>
      <div class="d-flex">
        <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
  <h1 class="h3 mb-4">Create new exam period</h1>

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $e): ?>
          <li><?php echo h($e); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Name</label>
      <input type="text" name="naziv" class="form-control"
             value="<?php echo h($_POST['naziv'] ?? ''); ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">From date</label>
      <input type="date" name="datum_od" class="form-control"
             value="<?php echo h($_POST['datum_od'] ?? ''); ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">To date</label>
      <input type="date" name="datum_do" class="form-control"
             value="<?php echo h($_POST['datum_do'] ?? ''); ?>" required>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Save</button>
      <a href="exam_periods.php" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
