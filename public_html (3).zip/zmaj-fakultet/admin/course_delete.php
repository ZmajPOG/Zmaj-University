<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $stmt = $pdo->prepare("DELETE FROM courses WHERE course_id = ?");
    $stmt->execute([$id]);
}

header('Location: courses.php?deleted=1');
exit;
