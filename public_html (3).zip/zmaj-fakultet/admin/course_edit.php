<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: courses.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM courses WHERE course_id = ?");
$stmt->execute([$id]);
$course = $stmt->fetch();

if (!$course) {
    header('Location: courses.php?notfound=1');
    exit;
}

$profStmt = $pdo->query("SELECT user_id, ime, prezime FROM users WHERE uloga = 'profesor' ORDER BY prezime, ime");
$professors = $profStmt->fetchAll();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naziv       = trim($_POST['naziv'] ?? '');
    $sifra       = trim($_POST['sifra'] ?? '');
    $espb        = trim($_POST['espb'] ?? '');
    $opis        = trim($_POST['opis'] ?? '');
    $profesor_id = (int)($_POST['profesor_id'] ?? 0);

    if ($naziv === '' || $sifra === '' || $espb === '' || $profesor_id === 0) {
        $errors[] = 'Name, code, ESPB and professor are required.';
    }

    if ($espb !== '' && !ctype_digit($espb)) {
        $errors[] = 'ESPB must be a whole number.';
    }

    if (!$errors) {
        $sql = "UPDATE courses
                SET naziv = :naziv,
                    sifra = :sifra,
                    espb = :espb,
                    opis = :opis,
                    profesor_id = :profesor_id
                WHERE course_id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':naziv'       => $naziv,
            ':sifra'       => $sifra,
            ':espb'        => (int)$espb,
            ':opis'        => $opis !== '' ? $opis : null,
            ':profesor_id' => $profesor_id,
            ':id'          => $id,
        ]);

        header('Location: courses.php?updated=1');
        exit;
    }
} else {
    // pre-fill
    $naziv       = $course['naziv'];
    $sifra       = $course['sifra'];
    $espb        = $course['espb'];
    $opis        = $course['opis'];
    $profesor_id = $course['profesor_id'];
}

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Zmaj University - Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">Users</a></li>
        <li class="nav-item"><a class="nav-link active" href="courses.php">Courses</a></li>
        <li class="nav-item"><a class="nav-link" href="exam_periods.php">Exam periods</a></li>
      </ul>
      <div class="d-flex">
        <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
  <h1 class="h3 mb-4">Edit course #<?php echo (int)$id; ?></h1>

  <?php if ($errors): ?>
    <div class="alert alert-danger">
      <ul class="mb-0">
        <?php foreach ($errors as $e): ?>
          <li><?php echo h($e); ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="post" class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Course name</label>
      <input type="text" name="naziv" class="form-control" value="<?php echo h($naziv); ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Code</label>
      <input type="text" name="sifra" class="form-control" value="<?php echo h($sifra); ?>" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">ESPB</label>
      <input type="number" min="1" max="30" name="espb" class="form-control"
             value="<?php echo h($espb); ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Professor</label>
      <select name="profesor_id" class="form-select" required>
        <option value="0">-- choose professor --</option>
        <?php foreach ($professors as $p): ?>
          <option value="<?php echo (int)$p['user_id']; ?>"
            <?php echo ((int)$profesor_id === (int)$p['user_id']) ? 'selected' : ''; ?>>
            <?php echo h($p['prezime'] . ' ' . $p['ime']); ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-12">
      <label class="form-label">Description</label>
      <textarea name="opis" rows="3" class="form-control"><?php echo h($opis); ?></textarea>
    </div>
    <div class="col-12">
      <button type="submit" class="btn btn-primary">Save changes</button>
      <a href="courses.php" class="btn btn-secondary">Back</a>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
