<?php
session_start();

if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'admin') {
    header('Location: ../index.php');
    exit;
}

require __DIR__ . '/../config/db.php';

// Simple stats for dashboard
$totalUsers        = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalProfessors   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE uloga = 'profesor'")->fetchColumn();
$totalStudents     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE uloga = 'student'")->fetchColumn();
$totalCourses      = (int)$pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn();
$totalExamPeriods  = (int)$pdo->query("SELECT COUNT(*) FROM exam_periods")->fetchColumn();
$activeExamPeriods = (int)$pdo->query("SELECT COUNT(*) FROM exam_periods WHERE aktivan = 1")->fetchColumn();
$totalEnrollments  = (int)$pdo->query("SELECT COUNT(*) FROM enrollments")->fetchColumn();
$totalApplications = (int)$pdo->query("SELECT COUNT(*) FROM exam_applications")->fetchColumn();

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>

<body class="bg-light">

<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-secondary fw-normal d-none d-sm-inline">Admin panel</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'users.php') echo 'active'; ?>" href="users.php">
            <i class="bi bi-people"></i> Users
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php') echo 'active'; ?>" href="courses.php">
            <i class="bi bi-journal-code"></i> Courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exam_periods.php') echo 'active'; ?>" href="exam_periods.php">
            <i class="bi bi-calendar-event"></i> Exam periods
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'announcements.php') echo 'active'; ?>" href="announcements.php">
            <i class="bi bi-megaphone"></i> Announcements
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'statistics.php') echo 'active'; ?>" href="statistics.php">
            <i class="bi bi-graph-up"></i> Statistics
          </a>
        </li>

      </ul>

      <div class="d-flex align-items-center">
        <span class="navbar-text me-3 small">
          <i class="bi bi-shield-lock-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>


<div class="container">
    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Total users</h6>
                    <h3 class="mb-0"><?php echo $totalUsers; ?></h3>
                    <small><?php echo $totalProfessors; ?> professors, <?php echo $totalStudents; ?> students</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Courses</h6>
                    <h3 class="mb-0"><?php echo $totalCourses; ?></h3>
                    <small>Managed by professors</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Exam periods</h6>
                    <h3 class="mb-0"><?php echo $totalExamPeriods; ?></h3>
                    <small><?php echo $activeExamPeriods; ?> active</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h6 class="text-muted mb-1">Exams & enrollments</h6>
                    <h3 class="mb-0"><?php echo $totalApplications; ?></h3>
                    <small><?php echo $totalEnrollments; ?> enrollments</small>
                </div>
            </div>
        </div>
    </div>

        <h5 class="mt-4 mb-3">Quick actions</h5>
    <div class="quick-actions-grid">

        <a href="users.php" class="quick-card quick-card-admin">
            <div class="quick-card-icon">
                <i class="bi bi-people-fill"></i>
            </div>
            <div>
                <div class="quick-card-title">User management</div>
                <div class="quick-card-main">Manage users</div>
                <div class="quick-card-text">
                    Create, edit or remove admins, professors and students.
                </div>
            </div>
        </a>

        <a href="courses.php" class="quick-card quick-card-admin">
            <div class="quick-card-icon">
                <i class="bi bi-journal-code"></i>
            </div>
            <div>
                <div class="quick-card-title">Courses</div>
                <div class="quick-card-main">Configure subjects</div>
                <div class="quick-card-text">
                    Set course name, code, ESPB and assign professors.
                </div>
            </div>
        </a>

        <a href="exam_periods.php" class="quick-card quick-card-admin">
            <div class="quick-card-icon">
                <i class="bi bi-calendar-event-fill"></i>
            </div>
            <div>
                <div class="quick-card-title">Exam periods</div>
                <div class="quick-card-main">Control exam terms</div>
                <div class="quick-card-text">
                    Create periods, activate or close them for applications.
                </div>
            </div>
        </a>

        <a href="statistics.php" class="quick-card quick-card-admin">
            <div class="quick-card-icon">
                <i class="bi bi-graph-up-arrow"></i>
            </div>
            <div>
                <div class="quick-card-title">Reports</div>
                <div class="quick-card-main">Open statistics</div>
                <div class="quick-card-text">
                    Overview of users, courses, enrollments and exam activity.
                </div>
            </div>
        </a>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
