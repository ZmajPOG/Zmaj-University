<?php
require __DIR__ . '/config/db.php';

$stmt = $pdo->query("SHOW TABLES");
$tables = $stmt->fetchAll();

echo "<h2>Database connection OK. Tables:</h2>";
echo "<pre>";
print_r($tables);
echo "</pre>";
