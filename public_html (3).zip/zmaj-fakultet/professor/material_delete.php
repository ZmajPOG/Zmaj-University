<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'profesor') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$professorId = (int)$_SESSION['user_id'];
$id          = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: materials.php');
    exit;
}

// Load material + course to check ownership and get file path
$stmt = $pdo->prepare("
    SELECT m.material_id, m.course_id, m.file_path, c.profesor_id
    FROM materials m
    JOIN courses c ON c.course_id = m.course_id
    WHERE m.material_id = ?
    LIMIT 1
");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row || (int)$row['profesor_id'] !== $professorId) {
    header('Location: materials.php');
    exit;
}

$courseId = (int)$row['course_id'];
$filePath = $row['file_path'];

$fullPath = dirname(__DIR__) . '/' . $filePath;
if (is_file($fullPath)) {
    @unlink($fullPath);
}

// Delete from DB
$stmt = $pdo->prepare("DELETE FROM materials WHERE material_id = ?");
$stmt->execute([$id]);

header('Location: materials.php?course_id=' . $courseId . '&msg=' . urlencode('Material deleted.'));
exit;
