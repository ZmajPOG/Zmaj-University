<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'profesor') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$professorId = (int)$_SESSION['user_id'];
$search = trim($_GET['q'] ?? '');

$sql = "
    SELECT
        c.course_id,
        c.naziv,
        c.sifra,
        c.espb,
        COUNT(e.enrollment_id) AS student_count
    FROM courses c
    LEFT JOIN enrollments e ON e.course_id = c.course_id
    WHERE c.profesor_id = :prof_id
";

$params = ['prof_id' => $professorId];

if ($search !== '') {
    $sql .= " AND (c.naziv LIKE :s1 OR c.sifra LIKE :s2)";
    $like = '%' . $search . '%';
    $params['s1'] = $like;
    $params['s2'] = $like;
}


$sql .= " GROUP BY c.course_id, c.naziv, c.sifra, c.espb
          ORDER BY c.sifra";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$courses = $stmt->fetchAll();

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Professor - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-light fw-normal d-none d-sm-inline">Professor</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarProf">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarProf">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php' || $current === 'course_students.php') echo 'active'; ?>"
             href="courses.php">
            <i class="bi bi-journal-bookmark"></i> My courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exams.php' || $current === 'exam_students.php') echo 'active'; ?>"
             href="exams.php">
            <i class="bi bi-clipboard-check"></i> Exams & grades
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'materials.php') echo 'active'; ?>"
             href="materials.php">
            <i class="bi bi-folder2-open"></i> Materials
          </a>
        </li>

      </ul>

      <div class="d-flex align-items-center">
        <span class="navbar-text me-3 small">
          <i class="bi bi-mortarboard-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>


<div class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">My courses</h1>
  </div>

  <form class="row g-2 align-items-center mb-3" method="get">
  <!-- Input should stretch -->
  <div class="col-12 col-md">
    <input type="text" class="form-control" name="q"
           placeholder="Search by name, code or professor"
           value="<?php echo h($search); ?>">
  </div>

  <!-- Buttons keep natural width -->
  <div class="col-12 col-md-auto">
    <button type="submit" class="btn btn-outline-secondary">Search</button>
    <?php if ($search !== ''): ?>
      <a href="courses.php" class="btn btn-link">Clear</a>
    <?php endif; ?>
  </div>
</form>


  <div class="table-responsive">
    <table class="table table-striped table-hover align-middle">
      <thead class="table-dark">
        <tr>
          <th>Code</th>
          <th>Name</th>
          <th>ESPB</th>
          <th>Students</th>
          <th style="width: 160px;">Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$courses): ?>
        <tr><td colspan="5" class="text-center text-muted">You are not assigned to any courses.</td></tr>
      <?php else: ?>
        <?php foreach ($courses as $c): ?>
          <tr>
            <td><?php echo h($c['sifra']); ?></td>
            <td><?php echo h($c['naziv']); ?></td>
            <td><?php echo (int)$c['espb']; ?></td>
            <td><?php echo (int)$c['student_count']; ?></td>
            <td>
              <a href="course_students.php?id=<?php echo (int)$c['course_id']; ?>"
                 class="btn btn-sm btn-outline-primary">
                View students
              </a>
              <!-- later: link to materials, grades, etc. -->
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
