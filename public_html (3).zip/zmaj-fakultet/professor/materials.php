<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'profesor') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$professorId = (int)$_SESSION['user_id'];

function h($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

// Optional: make PHP show errors while we debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------------------
// 1. Load professor's courses
// ---------------------------
try {
    $stmt = $pdo->prepare("
        SELECT course_id, sifra, naziv
        FROM courses
        WHERE profesor_id = ?
        ORDER BY sifra
    ");
    $stmt->execute([$professorId]);
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "DB error (courses): " . h($e->getMessage());
    exit;
}

$currentCourseId = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;

$validIds = $courses ? array_column($courses, 'course_id') : [];
if ($currentCourseId !== 0 && !in_array($currentCourseId, $validIds, true)) {
    $currentCourseId = 0; // invalid → show all
}

// Optional message (after upload/edit/delete)
$msg = $_GET['msg'] ?? null;

// ---------------------------
// 2. Load materials
// ---------------------------
$materials = [];

try {
    if ($currentCourseId > 0) {
        $sql = "
            SELECT m.material_id, m.title, m.description, m.file_path, m.uploaded_at,
                   c.sifra, c.naziv
            FROM materials m
            JOIN courses c ON c.course_id = m.course_id
            WHERE m.course_id = :cid
              AND c.profesor_id = :pid
            ORDER BY m.uploaded_at DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'cid' => $currentCourseId,
            'pid' => $professorId,
        ]);
        $materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // All materials for all professor's courses
        $sql = "
            SELECT m.material_id, m.title, m.description, m.file_path, m.uploaded_at,
                   c.sifra, c.naziv
            FROM materials m
            JOIN courses c ON c.course_id = m.course_id
            WHERE c.profesor_id = :pid
            ORDER BY c.sifra, m.uploaded_at DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['pid' => $professorId]);
        $materials = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    echo "DB error (materials): " . h($e->getMessage());
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Professor - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-light fw-normal d-none d-sm-inline">Professor</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarProf">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarProf">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php' || $current === 'course_students.php') echo 'active'; ?>"
             href="courses.php">
            <i class="bi bi-journal-bookmark"></i> My courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exams.php' || $current === 'exam_students.php') echo 'active'; ?>"
             href="exams.php">
            <i class="bi bi-clipboard-check"></i> Exams & grades
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'materials.php') echo 'active'; ?>"
             href="materials.php">
            <i class="bi bi-folder2-open"></i> Materials
          </a>
        </li>

      </ul>

      <div class="d-flex align-items-center">
        <span class="navbar-text me-3 small">
          <i class="bi bi-mortarboard-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>


<div class="container">
    <h1 class="h3 mb-3">Course materials</h1>

    <?php if ($msg): ?>
        <div class="alert alert-info"><?php echo h($msg); ?></div>
    <?php endif; ?>

    <?php if (!$courses): ?>
        <div class="alert alert-warning">
            You don't have any courses assigned, so you cannot upload materials.
        </div>
    <?php else: ?>
        <form method="get" class="row g-3 align-items-center mb-3">
            <div class="col-md-4">
                <label class="form-label">Filter by course</label>
                <select name="course_id" class="form-select" onchange="this.form.submit()">
                    <option value="0">All my courses</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?php echo (int)$c['course_id']; ?>"
                            <?php if ($currentCourseId === (int)$c['course_id']) echo 'selected'; ?>>
                            <?php echo h($c['sifra'] . ' - ' . $c['naziv']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($currentCourseId > 0): ?>
            <div class="col-md-4">
                <label class="form-label d-none d-md-block">&nbsp;</label>
                <a href="material_upload.php?course_id=<?php echo (int)$currentCourseId; ?>"
                   class="btn btn-success">
                    + Upload new material
                </a>
            </div>
            <?php endif; ?>
        </form>

        <?php if (!$materials): ?>
            <div class="alert alert-info">
                No materials found<?php echo $currentCourseId ? ' for this course.' : '.'; ?>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>Course</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Uploaded at</th>
                        <th style="width: 210px;">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($materials as $m): ?>
                        <tr>
                            <td><?php echo h($m['sifra'] . ' - ' . $m['naziv']); ?></td>
                            <td><?php echo h($m['title']); ?></td>
                            <td><?php echo h($m['description']); ?></td>
                            <td><?php echo h($m['uploaded_at']); ?></td>
                            <td>
                                <a href="../<?php echo h($m['file_path']); ?>" target="_blank"
                                   class="btn btn-sm btn-outline-secondary">
                                    Download
                                </a>
                                <a href="material_edit.php?id=<?php echo (int)$m['material_id']; ?>"
                                   class="btn btn-sm btn-outline-primary">
                                    Edit
                                </a>
                                <a href="material_delete.php?id=<?php echo (int)$m['material_id']; ?>"
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('Delete this material?');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
