<?php
// TEMP: show errors
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'profesor') {
    header('Location: ../index.php');
    exit;
}

require __DIR__ . '/../config/db.php';

$professorId = (int)($_SESSION['user_id'] ?? 0);
$courseId    = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$periodId    = isset($_GET['period_id']) ? (int)$_GET['period_id'] : 0;

if ($courseId <= 0 || $periodId <= 0) {
    header('Location: exams.php');
    exit;
}

// --------------------
// 1. Check that this course really belongs to this professor
// --------------------
try {
    $stmt = $pdo->prepare("
        SELECT course_id, sifra, naziv, espb
        FROM courses
        WHERE course_id = ? AND profesor_id = ?
    ");
    $stmt->execute([$courseId, $professorId]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('DB error (course check): ' . htmlspecialchars($e->getMessage()));
}

if (!$course) {
    header('Location: exams.php');
    exit;
}

// --------------------
// 2. Load exam period info
// --------------------
try {
    $stmt = $pdo->prepare("
        SELECT period_id, naziv, datum_od, datum_do, aktivan
        FROM exam_periods
        WHERE period_id = ?
    ");
    $stmt->execute([$periodId]);
    $period = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('DB error (period): ' . htmlspecialchars($e->getMessage()));
}

if (!$period) {
    header('Location: exams.php');
    exit;
}

$today = date('Y-m-d');
$gradingAllowed = false;
if (!empty($period['aktivan']) && $today >= $period['datum_od'] && $today <= $period['datum_do']) {
    $gradingAllowed = true;
}

$errors = [];

// --------------------
// 3. Handle POST: enter / update grade
// --------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicationId = isset($_POST['application_id']) ? (int)$_POST['application_id'] : 0;
    $studentId     = isset($_POST['student_id']) ? (int)$_POST['student_id'] : 0;
    $gradeValue    = isset($_POST['ocena']) ? (int)$_POST['ocena'] : 0;

    if (!$gradingAllowed) {
        $errors[] = 'Grades can be entered only while the exam period is active and today is within its date range.';
    } else {
        if ($applicationId <= 0 || $studentId <= 0 || $gradeValue < 5 || $gradeValue > 10) {
            $errors[] = 'Invalid data for grade.';
        } else {
            try {
                // Check that this application really exists and belongs to our course+period+student
                $stmt = $pdo->prepare("
                    SELECT application_id
                    FROM exam_applications
                    WHERE application_id = ?
                      AND student_id = ?
                      AND course_id = ?
                      AND period_id = ?
                ");
                $stmt->execute([$applicationId, $studentId, $courseId, $periodId]);
                $app = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$app) {
                    $errors[] = 'Exam application not found.';
                } else {
                    // Determine status from grade
                    $status    = ($gradeValue >= 6) ? 'polozio' : 'pao';
                    $todayDate = date('Y-m-d');

                    // Check if grade already exists for THIS exam application
                    $stmt = $pdo->prepare("
                        SELECT grade_id
                        FROM grades
                        WHERE application_id = ?
                        LIMIT 1
                    ");
                    $stmt->execute([$applicationId]);
                    $gradeId = $stmt->fetchColumn();
                    
                    if ($gradeId) {
                        // Update existing grade
                        $stmt = $pdo->prepare("
                            UPDATE grades
                            SET ocena = ?, datum = ?
                            WHERE grade_id = ?
                        ");
                        $stmt->execute([$gradeValue, $todayDate, $gradeId]);
                    } else {
                        // Insert new grade (tie it to this exam application)
                        $stmt = $pdo->prepare("
                            INSERT INTO grades (student_id, course_id, application_id, ocena, datum)
                            VALUES (?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([$studentId, $courseId, $applicationId, $gradeValue, $todayDate]);
                    }


                    // Update status in exam_applications
                    $stmt = $pdo->prepare("
                        UPDATE exam_applications
                        SET status = ?
                        WHERE application_id = ?
                    ");
                    $stmt->execute([$status, $applicationId]);
                }
            } catch (PDOException $e) {
                die('DB error (grading): ' . htmlspecialchars($e->getMessage()));
            }
        }
    }

    // Redirect (POST/Redirect/GET) to avoid resubmission
    header('Location: exam_students.php?course_id=' . $courseId . '&period_id=' . $periodId);
    exit;
}

// --------------------
// 4. Load students who applied for this course in this period
// --------------------
try {
    $sql = "
        SELECT
            ea.application_id,
            ea.status,
            u.user_id     AS student_id,
            u.indeks,
            u.ime,
            u.prezime,
            u.smer,
            g.grade_id,
            g.ocena,
            g.datum
        FROM exam_applications ea
        JOIN users u
          ON u.user_id = ea.student_id
        LEFT JOIN grades g
        ON g.application_id = ea.application_id

        WHERE ea.course_id = :course_id
          AND ea.period_id = :period_id
        ORDER BY u.indeks, u.prezime, u.ime
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'course_id' => $courseId,
        'period_id' => $periodId,
    ]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('DB error (load students): ' . htmlspecialchars($e->getMessage()));
}

function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Professor - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="/zmaj-fakultet/assets/img/favicon-128.png">
</head>
<body class="bg-light">
<?php $current = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">
      <span class="logo-pill">Z</span>
      Zmaj University
      <span class="ms-2 small text-light fw-normal d-none d-sm-inline">Professor</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarProf">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarProf">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'dashboard.php') echo 'active'; ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'courses.php' || $current === 'course_students.php') echo 'active'; ?>"
             href="courses.php">
            <i class="bi bi-journal-bookmark"></i> My courses
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'exams.php' || $current === 'exam_students.php') echo 'active'; ?>"
             href="exams.php">
            <i class="bi bi-clipboard-check"></i> Exams & grades
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?php if ($current === 'materials.php') echo 'active'; ?>"
             href="materials.php">
            <i class="bi bi-folder2-open"></i> Materials
          </a>
        </li>

      </ul>

      <div class="d-flex align-items-center">
        <span class="navbar-text me-3 small">
          <i class="bi bi-mortarboard-fill me-1"></i>
          <?php echo htmlspecialchars($_SESSION['ime'] . ' ' . $_SESSION['prezime'], ENT_QUOTES, 'UTF-8'); ?>
        </span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm">
          <i class="bi bi-box-arrow-right"></i> Logout
        </a>
      </div>
    </div>
  </div>
</nav>


<div class="container">
    <h1 class="h4 mb-3">
        Students in <?php echo h($course['sifra'] . ' - ' . $course['naziv']); ?>
    </h1>

    <p>
        Exam period:
        <strong><?php echo h($period['naziv']); ?></strong>
        (<?php echo h($period['datum_od']); ?> – <?php echo h($period['datum_do']); ?>)
        <br>
        Today: <strong><?php echo h($today); ?></strong>
        <?php if ($gradingAllowed): ?>
            <span class="badge bg-success ms-2">Grading is allowed</span>
        <?php else: ?>
            <span class="badge bg-secondary ms-2">Grading not allowed today</span>
        <?php endif; ?>
    </p>

    <a href="exams.php?period_id=<?php echo (int)$periodId; ?>" class="btn btn-outline-secondary btn-sm mb-3">
        ← Back to exams
    </a>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?php echo h($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (!$students): ?>
        <div class="alert alert-info">
            No students have applied for this exam in this period.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Index</th>
                    <th>Name</th>
                    <th>Program</th>
                    <th>Application status</th>
                    <th>Grade</th>
                    <th>Date</th>
                    <th style="width: 190px;">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                foreach ($students as $s):
                    $hasGrade = !empty($s['grade_id']);
                    $status    = $s['status'] ?? 'prijavljen';
                ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo h($s['indeks']); ?></td>
                        <td><?php echo h($s['ime'] . ' ' . $s['prezime']); ?></td>
                        <td><?php echo h($s['smer']); ?></td>
                        <td>
                            <?php if ($status === 'polozio'): ?>
                                <span class="badge bg-success">Passed</span>
                            <?php elseif ($status === 'pao'): ?>
                                <span class="badge bg-danger">Failed</span>
                            <?php else: ?>
                                <span class="badge bg-primary">Registered</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo $hasGrade ? (int)$s['ocena'] : '-'; ?></td>
                        <td><?php echo $hasGrade ? h($s['datum']) : '-'; ?></td>
                        <td>
                            <?php if (!$gradingAllowed): ?>
                                <span class="text-muted small">
                                    Grading disabled (outside exam period)
                                </span>
                            <?php else: ?>
                                <form method="post" class="d-flex align-items-center gap-2">
                                    <input type="hidden" name="application_id" value="<?php echo (int)$s['application_id']; ?>">
                                    <input type="hidden" name="student_id" value="<?php echo (int)$s['student_id']; ?>">
                                    <select name="ocena" class="form-select form-select-sm" style="width:90px;" required>
                                        <option value="">Grade</option>
                                        <?php for ($g = 5; $g <= 10; $g++): ?>
                                            <option value="<?php echo $g; ?>"
                                                <?php if ($hasGrade && (int)$s['ocena'] === $g) echo 'selected'; ?>>
                                                <?php echo $g; ?>
                                            </option>
                                        <?php endfor; ?>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-success">
                                        Save
                                    </button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
