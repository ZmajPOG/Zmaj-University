<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['uloga'] ?? '') !== 'profesor') {
    header('Location: ../index.php');
    exit;
}
require __DIR__ . '/../config/db.php';

$professorId = (int)$_SESSION['user_id'];
$courseId    = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;

if ($courseId <= 0) {
    header('Location: materials.php');
    exit;
}

// Check course belongs to this professor
$stmt = $pdo->prepare("
    SELECT course_id, sifra, naziv
    FROM courses
    WHERE course_id = ? AND profesor_id = ?
");
$stmt->execute([$courseId, $professorId]);
$course = $stmt->fetch();

if (!$course) {
    header('Location: materials.php');
    exit;
}

$errors = [];
$title = '';
$description = '';

function h($s) {
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($title === '') {
        $errors[] = 'Title is required.';
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
        $errors[] = 'File is required.';
    }

    if (!$errors && isset($_FILES['file'])) {
        $file = $_FILES['file'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'File upload error (code: ' . $file['error'] . ').';
        } else {
            $allowedExt = ['pdf','doc','docx','ppt','pptx','txt','zip'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowedExt, true)) {
                $errors[] = 'Allowed file types: pdf, doc, docx, ppt, pptx, txt, zip.';
            } elseif ($file['size'] > 10 * 1024 * 1024) { // 10 MB
                $errors[] = 'File is too large (max 10MB).';
            } else {
                $baseDir   = dirname(__DIR__) . '/uploads/materials/';
                if (!is_dir($baseDir)) {
                    if (!mkdir($baseDir, 0775, true)) {
                        $errors[] = 'Upload directory does not exist and could not be created. Please create "uploads/materials".';
                    }
                }

                if (!$errors) {
                    $newName = time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    $fullPath = $baseDir . $newName;

                    if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
                        $errors[] = 'Failed to move uploaded file.';
                    } else {
                        $relativePath = 'uploads/materials/' . $newName;

                        $stmt = $pdo->prepare("
                            INSERT INTO materials (course_id, title, description, file_path, uploaded_at)
                            VALUES (:cid, :title, :descr, :path, NOW())
                        ");
                        $stmt->execute([
                            'cid'   => $courseId,
                            'title' => $title,
                            'descr' => $description !== '' ? $description : null,
                            'path'  => $relativePath,
                        ]);

                        header('Location: materials.php?course_id=' . $courseId . '&msg=' . urlencode('Material uploaded.'));
                        exit;
                    }
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Professor - Zmaj University</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Custom Zmaj theme -->
  <link href="../assets/css/custom.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php">Zmaj University - Professor</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php $current = basename($_SERVER['PHP_SELF']); ?>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="courses.php">My courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="exams.php">Exams & grades</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="materials.php">Materials</a>
                </li>
            </ul>
            <div class="d-flex">
                <span class="navbar-text me-3">
                    Logged in as: <?php echo h($_SESSION['ime'] . ' ' . $_SESSION['prezime']); ?>
                </span>
                <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <h1 class="h4 mb-3">Upload material for <?php echo h($course['sifra'] . ' - ' . $course['naziv']); ?></h1>

    <?php if ($errors): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $e): ?>
                    <li><?php echo h($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="row g-3">
        <div class="col-md-6">
            <label class="form-label">Title</label>
            <input type="text" name="title" class="form-control"
                   value="<?php echo h($title); ?>" required>
        </div>
        <div class="col-md-12">
            <label class="form-label">Description (optional)</label>
            <textarea name="description" class="form-control" rows="3"><?php echo h($description); ?></textarea>
        </div>
        <div class="col-md-6">
            <label class="form-label">File</label>
            <input type="file" name="file" class="form-control" required>
            <div class="form-text">
                Allowed: pdf, doc, docx, ppt, pptx, txt, zip. Max 10MB.
            </div>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-success">Upload</button>
            <a href="materials.php?course_id=<?php echo (int)$courseId; ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
